# -*- coding: utf-8 -*-
"""
Created on Sat May 13 13:34:58 2017

@author: Vyankatesh
"""

#Start of the assignment#

import pandas as pd

import numpy as np

import os

import os,sys
from scipy import stats
import numpy as np

os.chdir("C:\Users\Vyankatesh\Desktop\Python Assignment")

data=pd.read_csv('simpleotc.csv')

output1 = data.describe()

output1

type(output1)

output2 = data.quantile([0.05, 0.10, 0.85, 0.95, 0.99])

output2

type(output2)

output4 = data.isnull().sum()

output4

out4 = pd.DataFrame([output4])

type(out4)

out4.rename(index={0:'Missing'}, inplace=True)

out4

type(output4)

percent = 100 * data.isnull().sum()/len(data)

percent

#convery series to dataframe#

out = pd.DataFrame([percent])

type(out)

out.rename(index={0:'Missing Perc'}, inplace=True)

frames = [output1, output2, out4, out]

result = pd.concat(frames)

result.rename(index={0.05:'q5', 0.1:'q10', 0.85:'q85', 0.95:'q95', 0.99:'q99'}, inplace=True)

result.rename(index={'25%':'q25', '50%':'q50', '75%':'q75',}, inplace=True)

result

type(result)

resultfinal = result.transpose()

resultfinal

resultfinal.to_csv('summary_statistics.csv')
